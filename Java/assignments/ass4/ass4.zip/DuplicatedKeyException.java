public class DuplicatedKeyException extends Exception {

    static final long serialVersionUID = 1;

    public DuplicatedKeyException(String err) {
        super(err);
    }
}

