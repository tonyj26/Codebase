public class EmptyTreeException extends Exception {

    static final long serialVersionUID = 1;

    public EmptyTreeException(String err) {
        super(err);
        }
}

