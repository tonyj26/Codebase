public class InexistentKeyException extends Exception {
    static final long serialVersionUID = 1;

    public InexistentKeyException(String err) {
        super(err);
        }
}

